import java.awt.*;
import javax.swing.*;

public class Main 
{
	public static void main(String[] args)
	{
		ShowBorderLayout frame = new ShowBorderLayout();
		frame.ShowBorderLayout();
		
		Color c = new Color(255,255,255);
		frame.getContentPane().setBackground(c);	
	}
	
	
	
	

//	JButton buttOK = new JButton("OK");
//	frame.add(buttOK);
	
	
}
