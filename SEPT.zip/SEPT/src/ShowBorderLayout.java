import java.awt.*;
import javax.swing.*;

public class ShowBorderLayout extends JFrame 
{
	public void ShowBorderLayout()
	{
		JFrame frame = new JFrame();
		JPanel panel = new JPanel(new BorderLayout());
		JPanel topPanel = new JPanel();
		JPanel bottomPanel = new JPanel();
		
		JButton buttonLeft = new JButton("Weather Stations");
		JButton buttonRight = new JButton("Favourites");
		
		bottomPanel.add(buttonLeft);
		bottomPanel.add(buttonRight);
		
		bottomPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		
		panel.add(topPanel, BorderLayout.NORTH);
		panel.add(bottomPanel, BorderLayout.SOUTH);
		
		JLabel label = new JLabel("Top Panel");
		topPanel.add(label);
		
		frame.add(panel);
		frame.setTitle("Weather App");
		frame.setSize(400,300);
		frame.setLocationRelativeTo(null); //centre the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		
	}

	
}
